export declare function isGhes(): boolean;
export declare function getCacheServiceVersion(): string;
export declare function getCacheServiceURL(): string;
